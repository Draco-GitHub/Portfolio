var dates = [];
for (let i = 0; i < 7; i++) {
    dates[i]=new Date();
    dates[i].setDate(dates[i].getDate() + (((1 + 7+i - dates[i].getDay()) % 7) || 7));
}

for (let i = 0; i < dates.length; i++) {
    getTDelta(dates[i],i);
}

function getTDelta(date,id){
    // Set the date we're counting down to
    var countDownDate = new Date(date).getTime();
    if(id==0){id="mo"}
    else if(id==1){id="tu"}
    else if(id==2){id="we"}
    else if(id==3){id="th"}
    else if(id==4){id="fr"}
    else if(id==5){id="sa"}
    else if(id==6){id="su"}

    // Update the count down every 1 second
    var x = setInterval(function() {
        var now = new Date().getTime();
        var distance = countDownDate - now;
        
        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        const element = document.querySelectorAll("#"+id);
        for (let i = 0; i < element.length; i++) {
            // Display the result in the element with id="demo"
            element[i].innerHTML= days + "d " + hours + "h " + minutes + "m " + seconds + "s ";
        }        
        
        // If the count down is finished, write some text
        for (let i = 0; i < element.length; i++) {
            if (distance < 0) {
                clearInterval(x);
                element[i].innerHTML = "EXPIRED";
              }
        }
    }, 1000);
}



