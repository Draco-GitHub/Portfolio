const links = ["../Pages/ANIME/index.html","../Pages/MANGA/index.html","https://myanimelist.net/animelist/ItsDraco"];

window.onload = (event) =>{
    document.getElementById('../Pages/ANIME/index.html').style.color = "#89CFF0";
    var iframe = document.createElement('iframe');
    
    iframe.allowFullscreen="true";
    iframe.webkitallowfullscreen="true";
    iframe.mozallowfullscreen="true";
    iframe.frameBorder=0;
    iframe.width="100%";
    iframe.height="100%";
    iframe.id="iframe";
    iframe.setAttribute("src", "../Pages/ANIME/index.html");
    document.getElementById("content").appendChild(iframe);
};

function defineContent(link){
    var element = document.getElementById('iframe');
    element.remove();
    
    for (let i = 0; i < links.length; i++) {
        document.getElementById(links[i]).style.color = "white";
    }

    document.getElementById(link).style.color = "#89CFF0";
    var iframe = document.createElement('iframe');
    iframe.allowFullscreen="true";
    iframe.webkitallowfullscreen="true";
    iframe.mozallowfullscreen="true";
    iframe.frameBorder=0;
    iframe.width="100%";
    iframe.height="100%";
    iframe.id="iframe";
    iframe.setAttribute("src", link);
    document.getElementById("content").appendChild(iframe);
}