HOW TO USE:

1. Open the Import folder
2. Edit either anime.txt or manga.txt to import data onto the website.
3.

Format:

Anime:
Name|Page Url|Image Url|Week
Name|Page Url|Image Url|Week
Name|Page Url|Image Url|Week

Week:

-Week is not needed but make sure to still place a "|" after Image Url even
if no week is entered.

Monday: mo
Tuesday: tu
Wednesday: we
Thursday: th
Friday: fr
Saturday: sa
Sunday: su

Manga:
Name|Page Url|Image Url
Name|Page Url|Image Url
Name|Page Url|Image Url

4. Do not leave an empty line or else the program will create an empty entry.
5. When done will all above steps execute the webstite.exe file for the html 
to be created.
6. The executable file will then open the website on your default browser.
